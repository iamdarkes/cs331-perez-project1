package cs331.sorting.vjdarkes;

import java.util.ArrayList;
import java.util.List;


public class MergeInsertionSort<T extends Comparable<T>> implements Sort<T>{
	private final Integer SWAP = 43;
	private Node<T> head = new Node<T>();
	
	@Override
	public void init(List<T> list) {
		Node<T> current = null;
		for (int i = 0; i < list.size(); i++){
			if (current == null){
				current = new Node<T>(list.get(i));
				head = current;
		
			}else{
				Node<T> nNode = new Node<T>(list.get(i));
				current.next = nNode;
				current = nNode;
			}
		}
		
	}

	@Override
	public List<T> getSortedList() {
		List<T> sortedList = new ArrayList<T>();
		Node<T> current = mergeSort(head);
		while (current != null){
			sortedList.add(current.val);
			current = current.next;
		}
		/*
		System.out.println("Sorted");

		for(int i = 0; i < sortedList.size(); ++i) {
			System.out.println(sortedList.get(i));
		}
		*/
		return sortedList;
	}
	
	
	public Node<T> mergeSort(Node<T> head){
	
		int count = 0;
		Node<T> current = head;
		while (current != null) {
			count++;
			current = current.next;
		}
		
		if (count <= SWAP){
			return insertionSort(head);
		}
		
 
		int mid = count / 2;
 
		Node<T> left = head, right = null;
		Node<T> elem2 = head;
		int half = 0;
		while (elem2 != null) {
			half++;
			Node<T> next = elem2.next;
 
			if (half == mid) {
				elem2.next = null;
				right = next;
			}
			elem2 = next;
		}
 
		Node<T> h1 = mergeSort(left);
		Node<T> h2 = mergeSort(right);
		Node<T> merged = merge(h1, h2);
 
		return merged;
	}

	public Node<T> merge(Node<T> left, Node<T>right){
		Node<T> elem1 = left;
		Node<T> elem2 = right;

		Node<T> temp = new Node<T>();
		Node<T> newNode = temp;

		while (elem1 != null || elem2 != null) {

			if (elem1 == null) {
				newNode.next = new Node<T>(elem2.val);
				elem1 = elem2.next;
				newNode = newNode.next;
			} else if (elem2 == null) {
				newNode.next = new Node<T>(elem1.val);
				elem1 = elem1.next;
				newNode = newNode.next;
			} else {
				if ((Integer)elem1.val < (Integer) elem2.val) {

					newNode.next = new Node<T>(elem1.val);
					elem1 = elem1.next;
					newNode = newNode.next;
				} else if (elem1.val == elem2.val) {
					newNode.next = new Node<T>(elem1.val);
					newNode.next.next = new Node<T>(elem1.val);
					newNode = newNode.next.next;
					elem1 = elem1.next;
					elem2 = elem2.next;

				} else {
					newNode.next = new Node<T>(elem2.val);
					elem2 = elem2.next;
					newNode = newNode.next;
				}
			}
		}
		return temp.next;
	}
	public Node<T> insertionSort(Node<T> head){
		if (head == null || head.next == null){
			return head;
		}
		 
        Node<T> sHead = new Node<T>();
        Node<T> prev,current,next;
        current = head;
        
        while (current != null) {
            next = current.next; 
            prev = sHead;
            while (prev.next != null && (Integer)prev.next.val <= (Integer) current.val) {
                prev = prev.next;
            }
            
            current.next = prev.next;
            prev.next = current;
            
            current = next;
        }
        return sHead.next;
		
	}
	
	public class Node<T extends Comparable<T>>{
		private T val;
		private Node<T> next;
		
		public Node(){
			 this.val = null;
			 this.next = null;
		}
		
		public Node (T value){
			this.val = value;
		
		}
	}

}
