package cs331.sorting.vjdarkes;

import java.util.ArrayList;
import java.util.List;


public class InsertionSort<T extends Comparable <T>> implements Sort<T> {

	Node<T> head = new Node<T>();

	public Node<T> insertionSort(Node<T> head){
		if (head == null || head.next == null){
			return head;
		}
		 
        Node<T> sHead = new Node<T>();
        Node<T> prev,current,next;
        current = head;

        while (current != null) {
            next = current.next; 
            prev = sHead;
            while (prev.next != null && (Integer)prev.next.val <= (Integer) current.val) {
                prev = prev.next;
            }
            
            current.next = prev.next;
            prev.next = current;
            
            current = next;
        }
        
        return sHead.next;
		
	}
	
	@Override
	public void init(List<T> list) {
		Node<T> current = null;
		for (int i = 0; i < list.size(); i++){
			if (current == null){
				current = new Node<T>(list.get(i));
				head = current;
		
			}else{
				Node<T> nNode = new Node<T>(list.get(i));
				current.next = nNode;
				current = nNode;
			}

		}
	}
	
	@Override
	public List<T> getSortedList() {
		
		List<T> list = new ArrayList<T>();
		Node<T> current = insertionSort(head);
		while (current != null){
			list.add(current.val);
			current = current.next;
		}
		//System.out.println("Sorted");

//		for(int i = 0; i < list.size(); ++i) {
//			System.out.println(list.get(i));
//		}
		return list;
	}

	public class Node <T extends Comparable<T>>{
		private T val;
		private Node<T> next;
		
		public Node(){
			 this.val = null;
			 this.next = null;
		}
		public Node(T value){
			this.val = value;
		}

	}

}
