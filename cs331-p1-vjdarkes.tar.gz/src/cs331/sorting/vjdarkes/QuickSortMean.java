package cs331.sorting.vjdarkes;

import java.util.ArrayList;
import java.util.List;

public class QuickSortMean<T extends Comparable <T>> implements Sort<T> {
    private Integer[] array;

    /**
     * This is the quick sort that uses the median as the pivot.
     * @param array array to be sorted
     * @param low low value of the array
     * @param high high value of the array
     * @return sorted array
     */
    public Integer[] quickSortMean(Integer[] array, int low, int high){
        if (array == null || array.length == 0){
            return array;
        }
        if (low >= high){
            return array;
        }
        //pivot is mean value
        int mean = ((high -1 + low) / 2);
        int pivot = array[mean];

        int i = low, j = high;
        while (i <= j) {
            while (array[i] < pivot) {
                i++;
            }
            while (array[j] > pivot) {
                j--;
            }
            if (i <= j) {
                swap(array, i,j);
                i++;
                j--;
            }
        }
        if (low < j){
            quickSortMean(array, low, j);
        }
        if (high > i){
            quickSortMean(array, i, high);
        }

        return array;
    }

    /**
     * Swap two values
     * @param arr array to have values swapped
     * @param index1 first value to be swapped
     * @param index2 second value to be swapped
     */
    private void swap(Integer[] arr, int index1, int index2) {
        Integer temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    /**
     * populates class member array with the lists values
     * @param list list to be filled with values
     */
    @Override
    public void init(List<T> list) {
        Integer[] arr = new Integer[list.size()];

        for(int i = 0; i< list.size();i++){
            arr[i] = (Integer) list.get(i);
        }
        array = arr;
    }

    /**
     * This generates a sorted List from the Array that has the
     * unsorted list and returns that sorted list
     */
    @Override
    public List getSortedList() {
        quickSortMean(array,0,array.length -1);
        List<Integer> intList = new ArrayList<Integer>(array.length);
        for (int i=0; i<array.length; i++)
        {
            intList.add(array[i]);
        }
        return intList;

    }
}
