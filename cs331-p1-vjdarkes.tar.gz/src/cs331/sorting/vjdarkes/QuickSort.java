package cs331.sorting.vjdarkes;

import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

/**
 This implementation of the quick sort algorithm is iterative and does not use recursion.
 */
public class QuickSort<T extends Comparable <T>> implements Sort<T> {
	private Integer[] array;

	/**
	 * Uses a stack object to avoid the use of recursion in quick sort.
	 * @param unsorted array to be sorted
	 */

	public void quickSortIterative(Integer[] unsorted) {
		Stack stack = new Stack();
		stack.push(0);
		stack.push(unsorted.length);

		while (!stack.isEmpty()) {
			Object last = stack.pop();
			Object first = stack.pop();
			if ((Integer)last - (Integer)first < 2) {
				continue;
			}
			Integer pivot = (Integer)first + (((Integer)last - (Integer)first) / 2);

			pivot = partition(unsorted, pivot, (Integer) first , (Integer) last);
			stack.push(pivot + 1);
			stack.push(last);
			stack.push(first);
			stack.push(pivot);
		}
	}

	/**
	 * determines the index that will serve as the parition of the array
	 * @param arr array to have partition
	 * @param position
	 * @param start beginning value in array
	 * @param end ending value in array
	 * @return index that will be the partition
	 */
	private Integer partition(Integer[] arr, Integer position, Integer start, Integer end) {
		Integer low = start;
		Integer high = end - 2;
		Integer pivotItem = arr[position];
		swap(arr, position, end - 1);
		while (low < high) {
			if (arr[low] < pivotItem) {
				low++;
			} else if (arr[high] >= pivotItem) {
				high--;
			} else {
				swap(arr, low, high);
			}
		}
		int index = high;
		if (arr[high] < pivotItem) {
			index++;
		} swap(arr, end - 1, index);
		return index;
	}

	/**
	 * Swap two values
	 * @param arr array to have values swapped
	 * @param index1 first value to be swapped
	 * @param index2 second value to be swapped
	 */
	private void swap(Integer[] arr, int index1, int index2) {
		Integer temp = arr[index1];
		arr[index1] = arr[index2];
		arr[index2] = temp;
	}

	@Override
	public void init(List<T> list) {
		Integer[] arr = new Integer[list.size()];
		for(int i = 0; i< list.size();i++){
			arr[i] = (Integer) list.get(i);
		}
		array = arr;
	}

	@Override
	public List getSortedList() {
		quickSortIterative(array);
		List<Integer> list = new ArrayList<Integer>(array.length);
		for (int i=0; i<array.length; i++)
		{
			list.add(array[i]);
		}
		return list;
	}
}

