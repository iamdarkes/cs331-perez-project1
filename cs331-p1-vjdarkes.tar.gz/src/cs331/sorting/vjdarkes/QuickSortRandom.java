package cs331.sorting.vjdarkes;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QuickSortRandom<T extends Comparable <T>> implements Sort<T> {
	private Integer[] array;

    /**
     * This is the quick sort function that sets a Random element
     * as the Pivot.
     * @param array array to be sorted
     * @param low low value of array
     * @param high high value of array
     * @return sorted array
     */
	public Integer[] quickSortRandom(Integer[] array, int low, int high){
		Random rand = new Random();
		if (array == null || array.length == 0){
			return array;
		}
		if (low >= high){
			return array;
		}
		//Choosing a random Pivot based on the size of the array
		int random = rand.nextInt((high - low)+1)+low ;
		int pivot = array[random];

		int i = low, j = high;
		while (i <= j) {
			while (array[i] < pivot) {
				i++;
			}
			while (array[j] > pivot) {
				j--;
			}
			if (i <= j) {
				swap(array, i, j);
				i++;
				j--;
			}
		}
		if (low < j){
			quickSortRandom(array, low, j);
		}
		if (high > i){
			quickSortRandom(array, i, high);
		}
		return array;
	}

    /**
     * Swap two values
     * @param arr array to have values swapped
     * @param index1 first value to be swapped
     * @param index2 second value to be swapped
     */
    private void swap(Integer[] arr, int index1, int index2) {
        Integer temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    /**
     * populates class member array with the lists values
     * @param list list to be filled with values
     */
	@Override
	public void init(List<T> list) {
		Integer[] arr = new Integer[list.size()];
	//		System.out.println("unsorted");

		for(int i = 0; i< list.size();i++){
			arr[i] = (Integer) list.get(i);
	//		System.out.println(arr[i]);

		}
		array = arr;
	}

    /**
     * This generates a sorted List from the Array that has the
     * unsorted list and returns that sorted list
     */
	@Override
	public List getSortedList() {
		quickSortRandom(array,0,array.length -1);
		List<Integer> list = new ArrayList<Integer>(array.length);
//		System.out.println("Sorted");

		for (int i=0; i<array.length; i++)
		{
	//		System.out.println(array[i]);
		    list.add(array[i]);
		}
		return list;
		
	}
	
	

}
