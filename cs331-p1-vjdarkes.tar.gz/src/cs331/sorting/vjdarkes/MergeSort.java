package cs331.sorting.vjdarkes;

import java.util.ArrayList;
import java.util.List;

public class MergeSort<T extends Comparable <T>> implements Sort<T> {

	private Node<T> head = new Node<T>();
	
	@Override
	public void init(List<T> list) {
		Node<T> current = null;
		for (int i = 0; i < list.size(); i++){
			if (current == null){
				current = new Node<T>(list.get(i));
				head = current;
		
			}else{
				Node<T> nNode = new Node<T>(list.get(i));
				current.next = nNode;
				current = nNode;
			}

		}
	}
	@Override
	public List<T> getSortedList() {
		List<T> list = new ArrayList<T>();
		Node<T> current = mergeSort(head);
		while (current != null){
			list.add(current.val);
			current = current.next;
        }
        /*
        System.out.println("Sorted");

		for(int i = 0; i < list.size(); ++i) {
            System.out.println(list.get(i));
        }
   		*/


        return list;
	}
	
	
	public Node<T> mergeSort(Node<T> head){
		if (head == null || head.next == null)
			return head;
	
		int count = 0;
		Node<T> elem = head;
		while (elem != null) {
			count++;
			elem = elem.next;
		}
 
		int mid = count / 2;
 
		Node<T> left = head, right = null;
		Node<T> elem2 = head;
		int countHalf = 0;
		while (elem2 != null) {
			countHalf++;
			Node<T> next = elem2.next;
 
			if (countHalf == mid) {
				elem2.next = null;
				right = next;
			}
			elem2 = next;
		}
 
		Node<T> h1 = mergeSort(left);
		Node<T> h2 = mergeSort(right);
		Node<T> merged = mergelist(h1, h2);
 
		return merged;
	}

    public MergeSort(){

    }

	public Node<T> mergelist(Node<T> left, Node<T>right){
		Node<T> elem1 = left;
		Node<T> elem2 = right;
 
		Node<T> temp = new Node<T>();
		Node<T> newNode = temp;
 
		while (elem1 != null || elem2 != null) {
 
			if (elem1 == null) {
				newNode.next = new Node<T>(elem2.val);
                elem2 = elem2.next;
				newNode = newNode.next;
			} else if (elem2 == null) {
				newNode.next = new Node<T>(elem1.val);
				elem1= elem1.next;
				newNode = newNode.next;
			} else {
				if ((Integer)elem1.val < (Integer) elem2.val) {
					
					newNode.next = new Node<T>(elem1.val);
					elem1 = elem1.next;
					newNode = newNode.next;
				} else if (elem1.val == elem2.val) {
					newNode.next = new Node<T>(elem1.val);
					newNode.next.next = new Node<T>(elem1.val);
					newNode = newNode.next.next;
					elem1 = elem1.next;
					elem2 = elem2.next;
 
				} else {
					newNode.next = new Node<T>(elem2.val);
					elem2 = elem2.next;
					newNode = newNode.next;
				}
			}
		}

		return temp.next;
	}
	
	public class Node<T extends Comparable<T>>{
		private T val;
		private Node<T> next;
		
		public Node(){
			 this.val = null;
			 this.next = null;
		}
		
		public Node (T value){
			this.val = value;
		
		}

	}
}
